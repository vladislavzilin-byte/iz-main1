# IZ HAIR TREND — Stars (chaotic fade)

- Black background + starry sky with:
  - variable star sizes (many small, rare giants)
  - regions twinkle ~2x faster
  - per-star **chaotic full fade-outs** across the sky
- Polymer buttons with full sweep (no spark), 30% slower
- No center title / triangles / photo
- Languages: LT / EN / RU, pages: Portfolio / Shop / Training / Contacts

## Dev
npm i
npm run dev

## Build
npm run build
